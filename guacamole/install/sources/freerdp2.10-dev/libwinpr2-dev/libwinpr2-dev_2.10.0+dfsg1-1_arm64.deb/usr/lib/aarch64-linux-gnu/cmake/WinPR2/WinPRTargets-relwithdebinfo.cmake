#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "winpr" for configuration "RelWithDebInfo"
set_property(TARGET winpr APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(winpr PROPERTIES
  IMPORTED_LINK_INTERFACE_LIBRARIES_RELWITHDEBINFO ""
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libwinpr2.so.2.10.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libwinpr2.so.2"
  )

list(APPEND _cmake_import_check_targets winpr )
list(APPEND _cmake_import_check_files_for_winpr "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libwinpr2.so.2.10.0" )

# Import target "winpr-tools" for configuration "RelWithDebInfo"
set_property(TARGET winpr-tools APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(winpr-tools PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "winpr"
  IMPORTED_LINK_INTERFACE_LIBRARIES_RELWITHDEBINFO ""
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libwinpr-tools2.so.2.10.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libwinpr-tools2.so.2"
  )

list(APPEND _cmake_import_check_targets winpr-tools )
list(APPEND _cmake_import_check_files_for_winpr-tools "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libwinpr-tools2.so.2.10.0" )

# Import target "winpr-makecert" for configuration "RelWithDebInfo"
set_property(TARGET winpr-makecert APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(winpr-makecert PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/winpr-makecert"
  )

list(APPEND _cmake_import_check_targets winpr-makecert )
list(APPEND _cmake_import_check_files_for_winpr-makecert "${_IMPORT_PREFIX}/bin/winpr-makecert" )

# Import target "winpr-hash" for configuration "RelWithDebInfo"
set_property(TARGET winpr-hash APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(winpr-hash PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/winpr-hash"
  )

list(APPEND _cmake_import_check_targets winpr-hash )
list(APPEND _cmake_import_check_files_for_winpr-hash "${_IMPORT_PREFIX}/bin/winpr-hash" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
