#ifndef FREERDP_BUILD_CONFIG_H
#define FREERDP_BUILD_CONFIG_H

#define FREERDP_DATA_PATH "/usr/share/freerdp2"
#define FREERDP_KEYMAP_PATH ""
#define FREERDP_PLUGIN_PATH "lib/aarch64-linux-gnu/freerdp2"

#define FREERDP_INSTALL_PREFIX "/usr"

#define FREERDP_LIBRARY_PATH "lib/aarch64-linux-gnu"

#define FREERDP_ADDIN_PATH "lib/aarch64-linux-gnu/freerdp2"

#define FREERDP_SHARED_LIBRARY_SUFFIX ".so"
#define FREERDP_SHARED_LIBRARY_PREFIX  "lib"

#define FREERDP_VENDOR_STRING "FreeRDP"
#define FREERDP_PRODUCT_STRING "FreeRDP"


#endif /* FREERDP_BUILD_CONFIG_H */
