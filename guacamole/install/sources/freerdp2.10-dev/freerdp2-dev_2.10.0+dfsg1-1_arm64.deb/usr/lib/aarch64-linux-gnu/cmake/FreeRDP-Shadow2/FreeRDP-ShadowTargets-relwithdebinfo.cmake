#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "freerdp-shadow" for configuration "RelWithDebInfo"
set_property(TARGET freerdp-shadow APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(freerdp-shadow PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "freerdp;freerdp-server;winpr;winpr-tools"
  IMPORTED_LINK_INTERFACE_LIBRARIES_RELWITHDEBINFO ""
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libfreerdp-shadow2.so.2.10.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libfreerdp-shadow2.so.2"
  )

list(APPEND _cmake_import_check_targets freerdp-shadow )
list(APPEND _cmake_import_check_files_for_freerdp-shadow "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libfreerdp-shadow2.so.2.10.0" )

# Import target "freerdp-shadow-subsystem" for configuration "RelWithDebInfo"
set_property(TARGET freerdp-shadow-subsystem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(freerdp-shadow-subsystem PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "freerdp-shadow;freerdp;winpr"
  IMPORTED_LINK_INTERFACE_LIBRARIES_RELWITHDEBINFO ""
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libfreerdp-shadow-subsystem2.so.2.10.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libfreerdp-shadow-subsystem2.so.2"
  )

list(APPEND _cmake_import_check_targets freerdp-shadow-subsystem )
list(APPEND _cmake_import_check_files_for_freerdp-shadow-subsystem "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libfreerdp-shadow-subsystem2.so.2.10.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
